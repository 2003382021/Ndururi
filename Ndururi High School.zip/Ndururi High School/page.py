x=2
y=5
if(x>y){
    print"i love you";
}
else;
print"babe"
print x

